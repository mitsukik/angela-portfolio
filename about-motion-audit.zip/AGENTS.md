<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

# Angela Yu Portfolio

## Project

Personal portfolio website for Angela Yu, Product Designer based in Taiwan.

Tech stack:
- Next.js
- React
- TypeScript
- Tailwind CSS

## Design Direction

Dark Editorial Minimal.

The site should feel:
- minimal
- editorial
- sophisticated
- modern
- product-design focused
- visually strong without looking over-designed

Avoid:
- generic SaaS aesthetics
- excessive cards
- glassmorphism across the whole site
- gradients
- decorative blobs
- heavy shadows
- unnecessary animation

## Colors

Background:
#111111

Primary text:
#F2F0EC

Purple:
#B9A7FF

Acid yellow:
#E7F34B

## Visual Rules

Main content areas, project images, and editorial sections should generally use sharp corners.

Rounded corners are acceptable for interactive navigation elements.

The navigation may use subtle iOS-style frosted glass.

## Homepage Structure

Current homepage:

1. Header
2. Hero
3. Selected Work
4. Footer / Contact

Do not add unnecessary homepage sections unless explicitly requested.

## Hero

The Hero design is approved.

Main headline:

將複雜的系統，
設計得清晰而直覺。

複雜 and 直覺 use acid yellow.

Eyebrow:

Product Designer | Based In Taiwan

Product Designer uses purple.
Based In Taiwan uses acid yellow.

Do not redesign the Hero unless explicitly requested.

## Selected Work

There are four projects:

01 Complex System
02 Corporate Website
03 IoT System
04 Consumer Product

Project data should remain data-driven.

The homepage project presentation should remain editorial and minimal.

## Responsive Design

Desktop, tablet, and mobile must all work well.

Do not simply shrink the desktop layout for mobile.

Mobile layouts should be intentionally composed for smaller screens.

## Navigation

Desktop and mobile navigation are sticky.

The navigation uses a subtle frosted-glass treatment.

Mobile navigation:
- expandable
- floating overlay
- must not push page content downward
- animated with subtle vertical movement and opacity
- chevron rotates when toggled
- expanded state does not show the word CLOSE

## Motion

Do not add heavy animation yet.

Later motion may include:
- subtle parallax
- scroll-driven Selected Work transitions
- text/image reveals
- smooth project transitions

Motion should feel restrained and editorial.

Mobile motion should be simpler than desktop.

Respect prefers-reduced-motion.

## Working Rules

- Preserve approved design decisions.
- Make scoped changes.
- Do not redesign unrelated sections.
- Do not change typography, colors, or layout without a clear reason.
- Prefer reusable components and clean data structures.
- Keep responsive behavior intact.
- Explain significant structural changes before implementing them.
- Do not add dependencies unless they are genuinely necessary.
